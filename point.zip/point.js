const sqlite3 = require('sqlite3').verbose();
const Discord = require('discord.js');
const fs = require('fs');

module.exports = {
  name: 'point',
  description: 'إعطاء نقاط لأشخاص معينين',
  execute(message, args) {

    if(!message.member.hasPermission('ADMINISTRATOR')) {
      return message.channel.send('ليس لديك الصلاحية لاستخدام هذا الأمر.');
    }


    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!member) {
      return message.channel.send('يرجى ذكر عضو صحيح لإعطائه نقاط.');
    }


    const points = parseInt(args[1]);
    if (isNaN(points)) {
      return message.channel.send('يرجى تحديد عدد نقاط صحيح لإعطاء العضو.');
    }


    const folderPath = 'databases/pointsdb/';
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath, { recursive: true });
    }


    const db = new sqlite3.Database(`${folderPath}points_${message.guild.id}.db`);


    db.run('CREATE TABLE IF NOT EXISTS points (user_id TEXT, points INTEGER)');


    db.get('SELECT points FROM points WHERE user_id = ?', [member.id], function(err, row) {
      if (err) {
        console.error(err);
        return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
      }

      let currentPoints = 0;
      if (row) {
        currentPoints = row.points;
      }


      const totalPoints = currentPoints + points;


      if (row) {
        db.run('UPDATE points SET points = ? WHERE user_id = ?', [totalPoints, member.id], function(err) {
          if (err) {
            console.error(err);
            return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
          }
        });
      } else {
        db.run('INSERT INTO points (user_id, points) VALUES (?, ?)', [member.id, totalPoints], function(err) {
          if (err) {
            console.error(err);
            return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
          }
        });
      }


      const embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('عدد النقاط')
        .setDescription(`مجموع النقاط الكلي: ${totalPoints}`);


      db.all('SELECT user_id, points FROM points', function(err, rows) {
        if (err) {
          console.error(err);
          return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
        }

        rows.sort((a, b) => b.points - a.points); 

        rows.forEach((row, index) => {
          const member = message.guild.members.cache.get(row.user_id);
          embed.addField(`العضو ${index + 1}`, `${member} - ${row.points} نقطة`);
        });

        message.channel.send(embed);
      });
    });

    db.close();
  },
};